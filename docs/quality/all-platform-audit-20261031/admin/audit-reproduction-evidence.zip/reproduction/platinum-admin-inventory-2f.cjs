const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root='/workspace/scratch/f9638ed3020b/platinum-circles';
const ts=require(path.join(root,'node_modules/typescript'));
const out=path.join(root,'docs/quality/all-platform-audit-20261031/admin');
function files(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(dir,e.name)):[path.join(dir,e.name)]);}
function pure(name,imports={}){const module={exports:{}};vm.runInNewContext(ts.transpileModule(fs.readFileSync(path.join(root,'admin-web/lib',name+'.ts'),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,{module,exports:module.exports,require:n=>{if(n in imports)return imports[n];throw Error(n);}});return module.exports;}
const policy=pure('permissions'),nav=pure('navigation',{'./permissions':policy});
const sources=files(path.join(root,'admin-web')).filter(f=>/\.(?:ts|tsx)$/.test(f)&&!f.includes('/node_modules/')&&!f.includes('/.next/')&&!f.includes('/tests/'));
const tests=files(path.join(root,'admin-web/tests')).filter(f=>f.endsWith('.cjs')).map(f=>({path:path.relative(root,f),text:fs.readFileSync(f,'utf8')}));
const records=[];let controlId=0;
for(const absolute of sources){
 const rel=path.relative(root,absolute),source=fs.readFileSync(absolute,'utf8'),sf=ts.createSourceFile(rel,source,ts.ScriptTarget.Latest,true,absolute.endsWith('x')?ts.ScriptKind.TSX:ts.ScriptKind.TS);
 const record={path:rel,kind:/\/page\.tsx$/.test(rel)?'page':/\/route\.ts$/.test(rel)?'endpoint':rel.includes('/app/')&&/actions\.ts$/.test(rel)?'action-module':'module',route:null,authGuards:[],permissionReferences:[],controls:[],serverActions:[],imports:[],referencedTests:[]};
 if(record.kind==='page'||record.kind==='endpoint')record.route='/'+rel.replace(/^admin-web\/app\//,'').replace(/\/(?:page\.tsx|route\.ts)$/,'').replace(/^(?:page\.tsx|route\.ts)$/,'');
 const line=n=>sf.getLineAndCharacterOfPosition(n.getStart(sf)).line+1;
 const txt=n=>n?n.getText(sf):'';
 const literal=n=>n&&ts.isStringLiteralLike(n)?n.text:null;
 const attrs=n=>Object.fromEntries(n.attributes.properties.filter(ts.isJsxAttribute).map(a=>[a.name.getText(sf),!a.initializer?true:ts.isStringLiteral(a.initializer)?a.initializer.text:ts.isJsxExpression(a.initializer)?txt(a.initializer.expression):txt(a.initializer)]));
 const label=n=>{const pieces=[];function walk(c){if(ts.isJsxText(c)&&c.text.trim())pieces.push(c.text.trim().replace(/\s+/g,' '));else if(ts.isJsxExpression(c)&&c.expression)pieces.push('{'+txt(c.expression).slice(0,100)+'}');else ts.forEachChild(c,walk);}if(ts.isJsxElement(n.parent))n.parent.children.forEach(walk);return pieces.join(' ').slice(0,240);};
 const permissionContext=n=>{for(let p=n.parent;p;p=p.parent)if(ts.isJsxElement(p)&&txt(p.openingElement.tagName)==='PermissionGate')return attrs(p.openingElement).permission||null;return null;};
 const useServer=sf.statements.some(n=>ts.isExpressionStatement(n)&&literal(n.expression)==='use server');
 function visit(n){
  if(ts.isImportDeclaration(n))record.imports.push({module:literal(n.moduleSpecifier),bindings:n.importClause?txt(n.importClause):''});
  if(ts.isCallExpression(n)){const name=txt(n.expression);if(['requireDesk','requirePermission','getAdmin','adminFromToken'].includes(name))record.authGuards.push({name,argument:literal(n.arguments[0]),line:line(n)});if(['canPerform','canOpen','allowedDesks'].includes(name))record.permissionReferences.push({name,arguments:n.arguments.map(a=>literal(a)||txt(a)),line:line(n)});}
  if((ts.isJsxOpeningElement(n)||ts.isJsxSelfClosingElement(n))){const tag=txt(n.tagName),a=attrs(n);if(['button','a','Link','input','select','textarea','form','CommandForm','PermissionGate','ActionPopover','ReviewForm','SecurityForm','SignInButton'].includes(tag)||a.onClick||a.onSubmit||a.role==='button')record.controls.push({id:'ADMIN-C'+String(++controlId).padStart(4,'0'),line:line(n),tag,label:a['aria-label']||a.title||label(n)||null,attributes:Object.fromEntries(Object.entries(a).filter(([k])=>['href','action','scope','type','name','onClick','onSubmit','disabled','required','minLength','maxLength','value','permission','role','aria-label'].includes(k))),permissionContext:permissionContext(n),runtimeStatus:'not-yet-exercised'});}
  if(ts.isFunctionDeclaration(n)&&n.name&&n.modifiers?.some(m=>m.kind===ts.SyntaxKind.ExportKeyword)&&n.modifiers?.some(m=>m.kind===ts.SyntaxKind.AsyncKeyword)&&(useServer||record.kind==='endpoint')){
   const calls=[];function scan(c){if(ts.isCallExpression(c)&&['runAdminCommand','requirePermission','requireDesk','command'].includes(txt(c.expression)))calls.push({callee:txt(c.expression),arguments:c.arguments.map(a=>literal(a)||txt(a).slice(0,180))});ts.forEachChild(c,scan);}scan(n);record.serverActions.push({name:n.name.text,line:line(n),kind:record.kind==='endpoint'?'endpoint-method':'server-action',calls,runtimeStatus:'not-yet-exercised'});
  }ts.forEachChild(n,visit);
 }visit(sf);
 const local=rel.replace(/^admin-web\//,'');record.referencedTests=tests.filter(t=>t.text.includes(local)||t.text.includes(path.basename(rel))).map(t=>t.path);
 records.push(record);
}
const permissionNames=['verification','user_moderate','post_moderate','market_moderate','report_post','report_listing','report_user','support','ads','system','business_manage','organization_manage','staff_manage','account_delete','comment_delete'];
const roles=[...policy.STAFF_ROLES,'unknown_role'];
const roleMatrix=roles.map(role=>({role,desks:[...policy.allowedDesks(role)],permissions:permissionNames.filter(p=>policy.canPerform(role,p)),destinations:nav.navigationForRole(role).flatMap(g=>g.items.map(i=>i.href)),tools:nav.toolsForRole(role).map(i=>i.href),quickActions:nav.actionsForRole(role).map(a=>a.href)}));
const result={schemaVersion:1,recordedAt:new Date().toISOString(),sourceHead:'2f91218e71dbcaf94ea7b454a0e3562800bfe601',scope:'Static administrative inventory; a source control site is not a dynamically instantiated widget or a passed runtime test.',counts:{sourceModules:records.length,pageRoutes:records.filter(r=>r.kind==='page').length,endpoints:records.filter(r=>r.kind==='endpoint').length,controlSites:controlId,serverActions:records.flatMap(r=>r.serverActions).filter(a=>a.kind==='server-action').length,endpointMethods:records.flatMap(r=>r.serverActions).filter(a=>a.kind==='endpoint-method').length,staffRoles:policy.STAFF_ROLES.size,deniedRoleControls:1,permissionKinds:permissionNames.length,existingNodeTestFiles:tests.filter(t=>!t.path.includes('/browser/')).length},roleMatrix,records,limits:['AST control sites include hidden inputs, permission wrappers and generic reusable definitions; counts do not imply unique visible runtime actions.','Desk action arrays and dynamically rendered controls require supplementary source mapping and runtime inspection.','referencedTests is textual source-reference discovery, not proof that every branch/control is exercised.','No source or provider mutation was made.']};
fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'source-inventory.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({counts:result.counts,routes:records.filter(r=>r.kind==='page').map(r=>({route:r.route,guards:r.authGuards})),path:path.join(out,'source-inventory.json')},null,2));
