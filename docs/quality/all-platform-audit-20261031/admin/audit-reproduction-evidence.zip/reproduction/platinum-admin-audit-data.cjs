const {ACTOR,TARGET,NOW,KEY}=require('/tmp/platinum-admin-page-audit.cjs');
const second='20000000-0000-4000-8000-000000000005';
const stamp=new Date(NOW-3600000).toISOString();
const profiles=[TARGET,second].map((id,i)=>({id,full_name:i?'Blake Audit':'Avery Audit',username:i?'blake.audit':'avery.audit',email:`member${i}@example.invalid`,avatar_url:null,account_type:'personal',profile_visibility:'public',created_at:stamp,last_seen:stamp,location:'Austin',bio:'Synthetic audit member',is_verified:i===0,verified_tier:i===0?'public_figure':null,verified_category:'community',deactivated_at:null,suspended_reason:null,restricted_until:null,follower_counts:[{count:2}],following_counts:[{count:1}],strike_counts:[{count:0}]}));
const tables={
 profiles,
 jobs:[TARGET,second].map((id,i)=>({id,title:i?'Support specialist':'Product designer',company:i?'Desert Studio':'North Studio',description:'Synthetic role description',posted_by:id,job_type:i?'contract':'full_time',location:i?'London':'Remote',status:'open',created_at:stamp})),
 call_sessions:[TARGET,second].map((id,i)=>({id,initiator_id:id,receiver_id:i?TARGET:second,created_at:stamp,started_at:i?null:stamp,duration_sec:i?0:60,status:i?'ringing':'ended',is_video:i===0,is_group_call:false})),
 posts:[TARGET,second].map((id,i)=>({id,user_id:id,content:i?'Second synthetic post':'A public synthetic post',body:'Synthetic body',created_at:stamp,media_url:null,likes_count:2,comments_count:0,shares_count:0,scope:'global',audience:'everyone',is_exclusive:false,community_id:null,archived_at:null})),
 marketplace_listings:[TARGET,second].map((id,i)=>({id,seller_id:id,title:i?'Travel notebook':'Desk lamp',description:'Synthetic listing',price:25,currency:'USD',status:'active',category:'home',location:'Austin',created_at:stamp,media_urls:[],media_url:null,images:[]})),
 stories:[TARGET,second].map((id,i)=>({id,user_id:id,content:i?'Second synthetic story':'Hello story',body:'Synthetic story',created_at:stamp,expires_at:new Date(NOW+3600000).toISOString(),media_url:null,media_type:'text',type:'text',views_count:0,audience:'everyone'})),
 verification_applications:[TARGET,second].map((id,i)=>({id,applicant_id:id,status:i?'under_review':'submitted',tier:'public_figure',category:'community',created_at:stamp,decided_at:null,statement:'A sufficiently detailed synthetic application statement.',evidence_links:['https://example.invalid/evidence'],decision_reason:null})),
 support_tickets:[TARGET,second].map((id,i)=>({id,user_id:id,kind:'support',subject:i?'Second audit ticket':'Synthetic billing question',body:'Please review this synthetic ticket.',status:i?'pending':'open',created_at:stamp,updated_at:stamp})),
 support_messages:[TARGET,second].map((id,i)=>({id,ticket_id:TARGET,sender:i?'ops':'member',sender_id:i?ACTOR:TARGET,body:i?'Synthetic staff answer':'Synthetic member question',created_at:new Date(NOW-(2-i)*60000).toISOString()})),
 feature_flags:[{key:'fixture_feature',enabled:false,note:'Synthetic audit feature'}],
 announcements:[{id:TARGET,title:'Synthetic notice',body:'Synthetic notice body',active:true,created_at:stamp}],
 blocked_words:[{word:'fixture-phrase',created_at:stamp}],
 admin_users:[{user_id:ACTOR,role:'super_admin',active:true,created_at:stamp},{user_id:TARGET,role:'support_agent',active:true,created_at:stamp}],
 organizations:[{id:TARGET,name:'Synthetic organization',slug:'audit-organization',kind:'business',parent_id:null,profile_id:TARGET,created_at:stamp,archived_at:null}],
 org_memberships:[{org_id:TARGET,user_id:TARGET,role:'owner',expires_at:null}],
 business_applications:[{id:TARGET,owner_id:TARGET,company_name:'Audit Business',desired_username:'audit.business',status:'submitted',created_at:stamp,decision_reason:null,decided_at:null}],
 studio_campaigns:[{id:TARGET,advertiser_id:TARGET,creator_id:TARGET,title:'Synthetic campaign',name:'Synthetic campaign',status:'submitted',created_at:stamp,updated_at:stamp,start_at:stamp,end_at:new Date(NOW+86400000).toISOString(),budget:20,budget_amount:20,currency:'USD',paid_amount:0}],
 admin_audit_log:[{id:TARGET,admin_id:ACTOR,action:'fixture.read',target_kind:'post',target_id:TARGET,reason:'Synthetic audit reason',before:null,after:null,created_at:stamp}],
};
const order={id:TARGET,buyer_id:TARGET,seller_id:second,title:'Travel notebook',quantity:1,status:'awaiting_seller',unit_minor:2500,delivery_minor:0,total_minor:2500,currency:'USD',created_at:stamp,updated_at:stamp,buyer_name:'Avery Audit',seller_name:'Blake Audit',fulfilment:'pickup',reservation:'reserved',version:1,events:[],payment:null};
const rpc={
 admin_support_triage_read:args=>args.p_ids.map(id=>({ticket_id:id,assigned_to:null,assigned_name:null,priority:'normal',queue:'general',escalated:false,version:1,response_due_at:null,support_commands_available:true})),
 admin_seller_review_reports:{rows:[],has_more:false,next_cursor:null},
 triniti_admin_deletion_requests:{rows:[],total:0,operator_review_available:true},
 admin_market_orders:{rows:[order],has_more:false,next_cursor:null},
 admin_market_order_detail:order,
 creator_finance_admin_snapshot:{environment:'test',enrollment_open:false,enrollments:[],payouts:[],next_cursor:null},
 admin_music_snapshot:{providers:[],licenses:[],originals:[],events:[]},
 admin_music_operations_snapshot:null,
 triniti_platinum_admin_command:args=>({success:true,command_key:args.p_key}),
 admin_support_triage_update:args=>({success:true,command_key:args.p_key}),
};
module.exports={tables,rpc,second,stamp,order,KEY};
