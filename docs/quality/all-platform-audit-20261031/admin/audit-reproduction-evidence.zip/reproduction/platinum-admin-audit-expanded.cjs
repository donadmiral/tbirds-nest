const fs=require('node:fs');
const {ROOT,makeHarness,runPage,KEY,TARGET}=require('/tmp/platinum-admin-page-audit.cjs');
const fixture=require('/tmp/platinum-admin-audit-data.cjs');
const inv=JSON.parse(fs.readFileSync(ROOT+'/docs/quality/all-platform-audit-20261031/admin/source-inventory.json','utf8'));
const perms=makeHarness().load(ROOT+'/admin-web/lib/permissions.ts');
const outcomes=[];
const summarize=r=>({file:r.file,scenario:r.scenario,role:r.role,outcome:r.outcome,error:r.error,redirect:r.redirect,cards:r.cards,forms:r.forms,controls:r.controls,desks:r.desks?.map(d=>({rows:d.rows.length,tabs:d.tabs,actions:d.actions,firstRow:d.rows[0]})),dataCalls:r.calls.filter(c=>!['/auth/v1/user','/rest/v1/admin_users','/rest/v1/rpc/triniti_admin_session_check'].includes(c.path))});
async function main(){
 const populated=[];
 for(const record of inv.records.filter(r=>r.kind==='page')) {
   const full=await runPage(record.path,{name:'populated',...fixture});populated.push(full);outcomes.push(summarize(full));
   for(const role of perms.STAFF_ROLES){
     if(role==='super_admin')continue;
     const r=await runPage(record.path,{name:'role-matrix',role,...fixture});
     outcomes.push(summarize(r));
   }
 }
 const actions=[];
 for(const record of inv.records)for(const action of record.serverActions||[]) {
  const command=action.calls?.find(c=>c.callee==='runAdminCommand');if(!command)continue;
  const permission=command.arguments[1];
  for(const role of [...perms.STAFF_ROLES,null,'unknown_role']) {
   const h=makeHarness({role,rpc:fixture.rpc});const fn=h.load(ROOT+'/'+record.path)[action.name];
   const data=new FormData();data.set('command_key',KEY);data.set('id',TARGET);if(action.name==='dismissReport')data.set('table','post_reports');
   let result,error;try{result=await fn(data);}catch(e){error=e.message||String(e);}
   const dispatched=h.calls.filter(c=>c.path==='/rest/v1/rpc/triniti_platinum_admin_command');
   actions.push({file:record.path,action:action.name,scenario:'permission-and-confirmed-receipt',role,permission,allowed:perms.canPerform(role||'',permission),dispatched:dispatched.length,result,error,revalidated:h.revalidated,pass:perms.canPerform(role||'',permission)?dispatched.length===1&&result?.success===true:dispatched.length===0&&Boolean(error)});
  }
  for(const [scenario,receipt]of [['unconfirmed-empty',null],['unconfirmed-wrong-key',{success:true,command_key:TARGET}],['provider-error',{__status:400,body:{code:'P0001',message:'TARGET_NOT_FOUND'}}],['missing-rpc',{__status:404,body:{code:'PGRST202',message:'Could not find the function public.triniti_platinum_admin_command(p_actor_id, p_session_id, p_key, p_operation, p_payload) in the schema cache'}}]]) {
   const h=makeHarness({rpc:{triniti_platinum_admin_command:receipt}});const data=new FormData();data.set('command_key',KEY);data.set('id',TARGET);if(action.name==='dismissReport')data.set('table','post_reports');
   let result,error;try{result=await h.load(ROOT+'/'+record.path)[action.name](data);}catch(e){error=e.message||String(e);}
   actions.push({file:record.path,action:action.name,scenario,role:'super_admin',result,error,revalidated:h.revalidated,pass:result?.success===false&&h.revalidated.length===0});
  }
 }
 fs.writeFileSync('/tmp/admin-populated-pages.json',JSON.stringify(populated,null,2)+'\n');
 fs.writeFileSync('/tmp/admin-expanded-contract-audit.json',JSON.stringify({sourceHead:'2f91218e71dbcaf94ea7b454a0e3562800bfe601',limits:['Synthetic provider responses only; no provider writes.','Role tests execute actual adminFromToken/requireDesk/requirePermission against synthetic Auth/session/staff responses.','Command confirmed-receipt cases verify dispatch/receipt gating, not SQL mutation execution or validity of each synthetic payload.','Client components remain leaves until separate browser check.'],routes:outcomes,actions},null,2)+'\n');
 console.log(JSON.stringify({routeScenarios:outcomes.length,rendered:outcomes.filter(r=>r.outcome==='rendered').length,actions:actions.length,uniqueActions:new Set(actions.map(a=>a.action)).size,actionFailures:actions.filter(a=>!a.pass),populated:populated.map(r=>({path:r.file,outcome:r.outcome,error:r.error}))}));
}
main().catch(e=>{console.error(e);process.exitCode=1});
