const fs=require('node:fs');
const {ROOT,runPage,NOW,TARGET}=require('/tmp/platinum-admin-page-audit.cjs');
const fixture=require('/tmp/platinum-admin-audit-data.cjs');
const id=n=>'50000000-0000-4000-8000-'+String(n).padStart(12,'0');
const iso=hours=>new Date(NOW+hours*3600000).toISOString();
const project=r=>({file:r.file,outcome:r.outcome,error:r.error,cards:r.cards,rows:r.desks?.map(d=>({count:d.rows.length,tabs:d.tabs,searchHint:d.searchHint,firstId:d.rows[0]?.id,lastId:d.rows.at(-1)?.id})),calls:r.calls.filter(c=>!c.path.includes('/auth/')&&!c.path.endsWith('/triniti_admin_session_check')&&!c.path.endsWith('/admin_users'))});
(async()=>{
const live=Array.from({length:250},(_,i)=>({id:id(i),user_id:TARGET,caption:'Live fixture '+i,created_at:iso(-2-i/10000),expires_at:iso(22-i/10000),views_count:1,media_type:'text',media_url:null}));
const expired=Array.from({length:250},(_,i)=>({id:id(i),user_id:TARGET,caption:'Expired fixture '+i,created_at:iso(-30-i/10000),expires_at:iso(-6-i/10000),views_count:1,media_type:'text',media_url:null}));
const pending=Array.from({length:1001},(_,i)=>({...fixture.tables.verification_applications[0],id:id(i),status:'submitted',created_at:iso(-1000+i/10),decided_at:null}));
const unique=Array.from({length:25},(_,i)=>({...fixture.tables.verification_applications[0],id:id(i),applicant_id:id(i+2000),status:'submitted',created_at:iso(-100+i),decided_at:null}));
const scenarios=[];
for(const [name,file,tables,expected]of [
 ['250-live-stories','admin-web/app/stories/page.tsx',{...fixture.tables,stories:live},{live:250,rows:250}],
 ['250-expired-last24h-normal24h-lifetime','admin-web/app/stories/page.tsx',{...fixture.tables,stories:expired},{expiredLast24:250}],
 ['1001-pending-verifications','admin-web/app/queue/page.tsx',{...fixture.tables,verification_applications:pending},{pending:1001,all:1001}],
 ['25-distinct-pending-applicants','admin-web/app/queue/page.tsx',{...fixture.tables,verification_applications:unique},{applicants:25}]
]){const result=await runPage(file,{...fixture,tables,name});scenarios.push({name,expected,...project(result)});console.log(JSON.stringify({name,outcome:result.outcome,cards:result.cards,strikeReadCount:result.calls.filter(c=>c.path.endsWith('/member_strikes')).length}));}
fs.writeFileSync(ROOT+'/docs/quality/all-platform-audit-20261031/admin/extra-metrics-projection.json',JSON.stringify({sourceHead:'2f91218e71dbcaf94ea7b454a0e3562800bfe601',scope:'Actual server pages, installed Supabase2.111 client and serviceClient wrapper with synthetic provider rows and API max_rows1000. No live provider queries/mutations.',scenarios},null,2)+'\n');
})().catch(e=>{console.error(e);process.exitCode=1});
