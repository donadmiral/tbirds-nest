const fs=require('node:fs');const path=require('node:path');const http=require('node:http');const assert=require('node:assert/strict');
const {chromium}=require('/workspace/scratch/f9638ed3020b/platinum-circles/web/node_modules/playwright');
const {ROOT,runPage,makeHarness,TARGET}=require('/tmp/platinum-admin-page-audit.cjs');const fixture=require('/tmp/platinum-admin-audit-data.cjs');
const inventory=JSON.parse(fs.readFileSync(ROOT+'/docs/quality/all-platform-audit-20261031/admin/source-inventory.json'));
const routes=inventory.records.filter(r=>r.kind==='page');
const actionFiles=new Map(inventory.records.flatMap(r=>(r.serverActions||[]).filter(a=>a.kind==='server-action').map(a=>[a.name,r.path])));
const OUT=ROOT+'/docs/quality/all-platform-audit-20261031/admin/browser';fs.mkdirSync(OUT,{recursive:true});
const checks=[],actions=[],errors=[],routeCoverage=[];let activeRoute='';
function json(res,obj,status=200){res.writeHead(status,{'content-type':'application/json'});res.end(JSON.stringify(obj));}
async function handler(req,res){try{
 const u=new URL(req.url,'http://localhost');
 if(u.pathname==='/fixture.js'||u.pathname==='/fixture.css'){res.writeHead(200,{'content-type':u.pathname.endsWith('js')?'application/javascript':'text/css'});res.end(fs.readFileSync(__dirname+'/build'+u.pathname));return;}
 if(req.method==='POST'&&u.pathname==='/__audit_action'){
  let raw='';for await(const c of req){raw+=c;if(raw.length>524288)throw new Error('Audit request too large');}const input=JSON.parse(raw);const file=actionFiles.get(input.action);if(!file)throw new Error('Unknown audit action');
  const rpc={...fixture.rpc};
  if(input.scenario==='unconfirmed')rpc.triniti_platinum_admin_command=null;
  if(input.scenario==='missing')rpc.triniti_platinum_admin_command={__status:404,body:{code:'PGRST202',message:'Could not find the function public.triniti_platinum_admin_command(p_actor_id, p_session_id, p_key, p_operation, p_payload) in the schema cache'}};
  if(input.scenario==='conflict')rpc.admin_support_triage_update={__status:400,body:{code:'P0001',message:'TRIAGE_CHANGED'}};
  const h=makeHarness({role:input.role,rpc,tables:fixture.tables});const data=new FormData();for(const[k,v]of input.fields)data.append(k,typeof v==='string'?v:new File([v.text],v.name,{type:v.type}));
  const record={action:input.action,scenario:input.scenario,role:input.role,fields:input.fields.filter(([k])=>!/password|token|secret/i.test(k)),value:null,error:null,redirect:null};
  try{record.value=await h.load(ROOT+'/'+file)[input.action](data);}catch(e){if(e.auditRedirect)record.redirect=e.auditRedirect;else record.error=e.message||String(e);}
  record.calls=h.calls;record.revalidated=h.revalidated;actions.push(record);json(res,record);return;
 }
 const match=routes.find(r=>r.route.replace(/\[[^\]]+\]/g,TARGET)===u.pathname);
 if(!match){const publicPath=path.resolve(ROOT+'/admin-web/public','.'+u.pathname);if(publicPath.startsWith(ROOT+'/admin-web/public/')&&fs.existsSync(publicPath)&&fs.statSync(publicPath).isFile()){res.writeHead(200);res.end(fs.readFileSync(publicPath));return;}res.writeHead(404);res.end('Audit route not found');return;}
 const role=u.searchParams.get('auditRole')||'super_admin';const rpc={...fixture.rpc};if(u.searchParams.get('auditCapability')==='missing')rpc.admin_support_triage_read={__status:404,body:{code:'PGRST202',message:'Could not find the function public.admin_support_triage_read(p_ids) in the schema cache'}};
 const result=await runPage(match.path,{...fixture,rpc,role,search:Object.fromEntries(u.searchParams),name:'actual-page-browser'});
 if(result.redirect){res.writeHead(302,{Location:result.redirect});res.end();return;}
 if(result.outcome!=='rendered'){json(res,result,500);return;}
 const pageJson=JSON.stringify(result).replace(/</g,'\\u003c');
 res.writeHead(200,{'content-type':'text/html'});res.end('<!doctype html><html data-theme="light"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="/fixture.css"><title>Actual admin page audit</title></head><body><div id="root"></div><script>window.__AUDIT_PAGE__='+pageJson+'</script><script src="/fixture.js"></script></body></html>');
 }catch(e){json(res,{error:String(e)},500);}}

async function main(){
 const server=http.createServer(handler);await new Promise((ok,bad)=>{server.once('error',bad);server.listen(0,'127.0.0.1',ok)});const origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({executablePath:'/tmp/platinum-audit-browser/chrome-linux64/chrome',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});const page=await browser.newPage({viewport:{width:390,height:844},reducedMotion:'reduce'});
 await page.route('**/*',route=>new URL(route.request().url()).origin===origin?route.continue():route.abort());
 const sample=()=>page.evaluate(()=>({viewport:innerWidth,documentWidth:document.documentElement.scrollWidth,workspace:((n)=>{const r=n.getBoundingClientRect();const s=getComputedStyle(n);return {left:r.left,right:r.right,width:r.width,padding:s.padding,minWidth:s.minWidth}})(document.querySelector('main')),overflow:[...document.querySelectorAll('main *')].map(n=>({tag:n.tagName,name:n.getAttribute('name'),text:(n.textContent||'').trim().slice(0,140),left:n.getBoundingClientRect().left,right:n.getBoundingClientRect().right,width:n.getBoundingClientRect().width})).filter(n=>n.right>innerWidth+1)}));
 try{await page.goto(origin+'/support/'+TARGET);await page.waitForSelector('select[name=assigned_to]');
 const original=await sample();
 await page.evaluate(()=>{const m=document.querySelector('main');m.removeAttribute('style');Object.assign(m.style,{flex:'1',minWidth:'0'});const outer=document.createElement('div');Object.assign(outer.style,{display:'flex',minHeight:'100vh',width:'100%'});m.parentNode.insertBefore(outer,m);outer.appendChild(m)});
 const actualWorkspaceGeometry=await sample();await page.screenshot({path:OUT+'/support-390-actual-workspace-geometry.png',fullPage:true});
 await page.evaluate(()=>{const s=document.querySelector('select[name=assigned_to]');s.style.maxWidth='100%';s.parentElement.style.minWidth='0';s.parentElement.style.maxWidth='100%'});
 const proposedConstraintProbe=await sample();await page.screenshot({path:OUT+'/support-390-constraint-probe.png',fullPage:true});
 const record={sourceHead:'2f91218e71dbcaf94ea7b454a0e3562800bfe601',scope:'Actual TicketPage owner-select markup and CSS; actual Workspace flex/minWidth and responsive .pc-workspace padding reproduced in local Shell adapter; no production change.',original,actualWorkspaceGeometry,proposedConstraintProbe,limits:['Full Shell header/rail not mounted. They do not constrain the owner select; the reproduced mobile Workspace has actual CSS padding16 instead of fixture padding24.','Staff social-profile fallback is a legitimate UUID plus role; no hosted staff data was accessed.','Constraint probe is temporary DOM-only diagnostic, not an accepted source repair.']};fs.writeFileSync(OUT+'/support-overflow-projection.json',JSON.stringify(record,null,2)+'\n');console.log(JSON.stringify(record));
 }finally{await browser.close();await new Promise(r=>server.close(r));}
}main().catch(e=>{console.error(e);process.exitCode=1});
