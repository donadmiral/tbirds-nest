const fs=require('node:fs');const path=require('node:path');const root='/workspace/scratch/f9638ed3020b/platinum-circles/admin-web';
const out='/tmp/platinum-admin-browser-audit/build';fs.mkdirSync(out,{recursive:true});
const {webpack}=require(root+'/node_modules/next/dist/compiled/webpack/webpack');
const inventory=require(root+'/../docs/quality/all-platform-audit-20261031/admin/source-inventory.json');
const actions=inventory.records.flatMap(r=>r.serverActions||[]).filter(a=>a.kind==='server-action').map(a=>a.name);
fs.writeFileSync(__dirname+'/actions.ts',"import {invoke} from './action-bridge';\n"+actions.map(name=>`export async function ${name}(data:FormData){return invoke('${name}',data);}`).join('\n'));
async function main(){
 await new Promise((resolve,reject)=>webpack({mode:'development',devtool:false,context:root,target:'web',entry:__dirname+'/fixture.tsx',output:{path:out,filename:'fixture.js'},plugins:[new webpack.DefinePlugin({'process.env.__NEXT_IMAGE_OPTS':'undefined','process.env.NEXT_DEPLOYMENT_ID':'undefined','process.env.NEXT_SUPPORTS_IMMUTABLE_ASSETS':'false','process.env.NEXT_RUNTIME':JSON.stringify('browser'),'process.env.NEXT_PUBLIC_SUPABASE_URL':JSON.stringify('https://platinum-admin-fixture.invalid')})],resolve:{modules:[root+'/node_modules','node_modules'],extensions:['.tsx','.ts','.js'],alias:{'@/lib/actions':__dirname+'/actions.ts','@':root,'next/link':__dirname+'/router-adapter.tsx','next/navigation':__dirname+'/router-adapter.tsx',react:root+'/node_modules/react','react-dom':root+'/node_modules/react-dom'}},module:{rules:[{test:/\.tsx?$/,exclude:/node_modules/,use:root+'/tests/browser/typescript-loader.cjs'}]}},(e,s)=>e?reject(e):s.hasErrors()?reject(new Error(s.toString({all:false,errors:true}))):resolve()));
 const postcss=require(root+'/node_modules/postcss');const tailwind=require('node:module').createRequire(root+'/package.json')('@tailwindcss/postcss');
 const result=await postcss([tailwind({base:root})]).process(fs.readFileSync(root+'/app/globals.css','utf8'),{from:root+'/app/globals.css'});fs.writeFileSync(out+'/fixture.css',result.css);
 console.log(JSON.stringify({out,compiledActualComponents:true,tailwind:true}));
}
main().catch(e=>{console.error(e);process.exitCode=1});
