const fs=require('node:fs');const path=require('node:path');const http=require('node:http');const assert=require('node:assert/strict');
const {chromium}=require('/workspace/scratch/f9638ed3020b/platinum-circles/web/node_modules/playwright');
const {ROOT,runPage,makeHarness,TARGET}=require('/tmp/platinum-admin-page-audit.cjs');const fixture=require('/tmp/platinum-admin-audit-data.cjs');
const inventory=JSON.parse(fs.readFileSync(ROOT+'/docs/quality/all-platform-audit-20261031/admin/source-inventory.json'));
const routes=inventory.records.filter(r=>r.kind==='page');
const actionFiles=new Map(inventory.records.flatMap(r=>(r.serverActions||[]).filter(a=>a.kind==='server-action').map(a=>[a.name,r.path])));
const OUT=ROOT+'/docs/quality/all-platform-audit-20261031/admin/browser';fs.mkdirSync(OUT,{recursive:true});
const checks=[],actions=[],errors=[],routeCoverage=[];let activeRoute='';
function json(res,obj,status=200){res.writeHead(status,{'content-type':'application/json'});res.end(JSON.stringify(obj));}
async function handler(req,res){try{
 const u=new URL(req.url,'http://localhost');
 if(u.pathname==='/fixture.js'||u.pathname==='/fixture.css'){res.writeHead(200,{'content-type':u.pathname.endsWith('js')?'application/javascript':'text/css'});res.end(fs.readFileSync(__dirname+'/build'+u.pathname));return;}
 if(req.method==='POST'&&u.pathname==='/__audit_action'){
  let raw='';for await(const c of req){raw+=c;if(raw.length>524288)throw new Error('Audit request too large');}const input=JSON.parse(raw);const file=actionFiles.get(input.action);if(!file)throw new Error('Unknown audit action');
  const rpc={...fixture.rpc};
  if(input.scenario==='unconfirmed')rpc.triniti_platinum_admin_command=null;
  if(input.scenario==='missing')rpc.triniti_platinum_admin_command={__status:404,body:{code:'PGRST202',message:'Could not find the function public.triniti_platinum_admin_command(p_actor_id, p_session_id, p_key, p_operation, p_payload) in the schema cache'}};
  if(input.scenario==='conflict')rpc.admin_support_triage_update={__status:400,body:{code:'P0001',message:'TRIAGE_CHANGED'}};
  const h=makeHarness({role:input.role,rpc,tables:fixture.tables});const data=new FormData();for(const[k,v]of input.fields)data.append(k,typeof v==='string'?v:new File([v.text],v.name,{type:v.type}));
  const record={action:input.action,scenario:input.scenario,role:input.role,fields:input.fields.filter(([k])=>!/password|token|secret/i.test(k)),value:null,error:null,redirect:null};
  try{record.value=await h.load(ROOT+'/'+file)[input.action](data);}catch(e){if(e.auditRedirect)record.redirect=e.auditRedirect;else record.error=e.message||String(e);}
  record.calls=h.calls;record.revalidated=h.revalidated;actions.push(record);json(res,record);return;
 }
 const match=routes.find(r=>r.route.replace(/\[[^\]]+\]/g,TARGET)===u.pathname);
 if(!match){const publicPath=path.resolve(ROOT+'/admin-web/public','.'+u.pathname);if(publicPath.startsWith(ROOT+'/admin-web/public/')&&fs.existsSync(publicPath)&&fs.statSync(publicPath).isFile()){res.writeHead(200);res.end(fs.readFileSync(publicPath));return;}res.writeHead(404);res.end('Audit route not found');return;}
 const role=u.searchParams.get('auditRole')||'super_admin';const rpc={...fixture.rpc};if(u.searchParams.get('auditCapability')==='missing')rpc.admin_support_triage_read={__status:404,body:{code:'PGRST202',message:'Could not find the function public.admin_support_triage_read(p_ids) in the schema cache'}};
 const result=await runPage(match.path,{...fixture,rpc,role,search:Object.fromEntries(u.searchParams),name:'actual-page-browser'});
 if(result.redirect){res.writeHead(302,{Location:result.redirect});res.end();return;}
 if(result.outcome!=='rendered'){json(res,result,500);return;}
 const pageJson=JSON.stringify(result).replace(/</g,'\\u003c');
 res.writeHead(200,{'content-type':'text/html'});res.end('<!doctype html><html data-theme="light"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="/fixture.css"><title>Actual admin page audit</title></head><body><div id="root"></div><script>window.__AUDIT_PAGE__='+pageJson+'</script><script src="/fixture.js"></script></body></html>');
 }catch(e){json(res,{error:String(e)},500);}}
async function main(){
 const server=http.createServer(handler);await new Promise((ok,bad)=>{server.once('error',bad);server.listen(0,'127.0.0.1',ok)});const origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({executablePath:'/tmp/platinum-audit-browser/chrome-linux64/chrome',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const context=await browser.newContext({viewport:{width:1440,height:1000},reducedMotion:'reduce'});const page=await context.newPage();page.setDefaultTimeout(6000);
 await context.route('**/*',route=>new URL(route.request().url()).origin===origin?route.continue():route.abort());
 page.on('pageerror',e=>errors.push({route:activeRoute,error:e.message}));
 const check=async(name,fn)=>{try{await fn();checks.push({name,route:activeRoute,status:'passed'});}catch(e){checks.push({name,route:activeRoute,status:'failed',error:String(e)});await page.screenshot({path:OUT+'/failure-'+checks.length+'.png',fullPage:true}).catch(()=>{});}console.log(JSON.stringify(checks.at(-1)));fs.writeFileSync('/tmp/admin-browser-live-checks.json',JSON.stringify({checks,errors}));};
 async function open(route){activeRoute=route;await page.goto(origin+route);await page.waitForFunction(()=>document.querySelector('#root')?.childElementCount>0);await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));}
 try{
  const populated=JSON.parse(fs.readFileSync('/tmp/admin-populated-pages.json'));
  for(const record of routes){const candidate=populated.find(r=>r.file===record.path);if(candidate?.outcome!=='rendered')continue;const route=record.route.replace(/\[[^\]]+\]/g,TARGET);
   await check('Actual server page renders its populated fixture output',async()=>{await open(route);assert.equal(errors.filter(e=>e.route===activeRoute).length,0);assert.ok((await page.locator('#root').innerText()).trim().length>0);});
   routeCoverage.push({route,file:record.path,visibleControls:await page.locator('button:visible,a:visible,input:visible,select:visible,textarea:visible,summary:visible').evaluateAll(nodes=>nodes.map(n=>({tag:n.tagName.toLowerCase(),text:(n.textContent||'').trim().slice(0,100),label:n.getAttribute('aria-label'),name:n.getAttribute('name'),href:n.getAttribute('href'),disabled:n.disabled===true}))),uncoveredFamilies:await page.locator('[data-audit-uncovered]').evaluateAll(nodes=>nodes.map(n=>n.getAttribute('data-audit-uncovered')))});
   for(const desk of candidate.desks||[]){
    await check('Actual Desk consumer search reaches empty state and Clear filters restores records',async()=>{const box=page.getByRole('textbox',{name:desk.searchHint||'Search records',exact:true});await box.fill('audit-no-record-7e33');await page.getByText(/^Nothing matches this view\./).first().waitFor();await page.getByRole('button',{name:'Clear filters',exact:true}).click();assert.equal(await box.inputValue(),'');});
    if(desk.rows.length>0)await check('Actual Desk consumer selects its fixture record and opens the correct detail',async()=>{const first=desk.rows[0];const row=page.getByRole('row',{name:first.detail.title,exact:true});if(await row.count())await row.click();else await page.getByRole('button',{name:new RegExp(first.detail.title.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'))}).first().click();assert.ok((await page.locator('.pc-review-detail').innerText()).includes(first.detail.title));});
    for(const filter of desk.filters||[]){if(!filter.options.length)continue;await check('Actual Desk '+filter.label+' facet applies and clears',async()=>{const select=page.locator('.pc-desk-toolbar').getByRole('combobox',{name:filter.label,exact:true});await select.selectOption(filter.options[0]);assert.equal(await select.inputValue(),filter.options[0]);await page.getByRole('button',{name:'Clear filters',exact:true}).click();assert.equal(await select.inputValue(),'All');});}
   }
  }
  await open('/queue');
  await check('Verification consumer sends selected application and required review basis to actual server action',async()=>{await page.getByRole('textbox',{name:'Approval review basis',exact:true}).fill('Synthetic review of identity, evidence and account eligibility.');await page.getByRole('button',{name:'Approve and grant the seal',exact:true}).click();await page.getByText('Changes saved.',{exact:true}).waitFor();const sent=actions.at(-1);assert.equal(sent.action,'approveApplication');const call=sent.calls.find(c=>c.path.endsWith('/triniti_platinum_admin_command'));assert.equal(call.body.p_payload.id,TARGET);assert.equal(call.body.p_operation,'approveApplication');assert.ok(call.body.p_payload.reason.length>=20);});
  await open('/support/'+TARGET+'?auditAction=unconfirmed');
  await check('Support reply shows unconfirmed receipt failure, keeps draft and reuses its command key',async()=>{const draft=page.locator('textarea[name="body"]');await draft.fill('Synthetic reply that must survive an unconfirmed receipt.');const send=page.getByRole('button',{name:/Send reply/});await send.click();await page.getByRole('alert').filter({hasText:'The change was not confirmed.'}).waitFor();assert.equal(await draft.inputValue(),'Synthetic reply that must survive an unconfirmed receipt.');const first=actions.at(-1);await send.click();await page.waitForFunction(n=>window.__AUDIT_ACTIONS__.length>=n,2);const second=actions.at(-1);assert.equal(first.fields.find(([k])=>k==='command_key')[1],second.fields.find(([k])=>k==='command_key')[1]);assert.equal(second.revalidated.length,0);});
  await open('/support/'+TARGET+'?auditCapability=missing');
  await check('Support capability loss keeps history visible and removes reply/status/assignment mutation controls',async()=>{await page.getByText('Synthetic member question',{exact:true}).waitFor();assert.equal(await page.locator('form[aria-busy]').count(),0);assert.match(await page.locator('main').innerText(),/unavailable|read.only/i);});
  await open('/support/'+TARGET+'?auditAction=conflict');
  await check('Stale support triage displays the conflict and preserves operator input',async()=>{await page.locator('input[name="reason"]').fill('Synthetic priority adjustment');await page.getByRole('button',{name:'Save assignment',exact:true}).click();await page.getByRole('alert').filter({hasText:'Another staff member updated this case.'}).waitFor();assert.equal(await page.locator('input[name="reason"]').inputValue(),'Synthetic priority adjustment');});
  await open('/users');
  await check('Actual UsersDesk record switch clears another member suspension reason',async()=>{await page.getByRole('textbox',{name:'Suspension reason',exact:true}).fill('Only belongs to Avery');await page.getByRole('row').filter({hasText:'Blake Audit'}).click();assert.equal(await page.getByRole('textbox',{name:'Suspension reason',exact:true}).inputValue(),'');assert.ok((await page.getByRole('region',{name:'Selected member details',exact:true}).innerText()).includes('Blake Audit'));});
  for(const route of ['/jobs','/calls','/support/'+TARGET,'/users','/system']){await open(route);await page.setViewportSize({width:390,height:844});await check('Actual page fits390px without document-level horizontal overflow',async()=>{assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),true);});await page.screenshot({path:OUT+'/'+route.split('/')[1]+'-390.png',fullPage:true});await page.setViewportSize({width:1440,height:1000});}
 }finally{
  const receipt={sourceHead:'2f91218e71dbcaf94ea7b454a0e3562800bfe601',runtime:await browser.version(),scope:'Actual frozen server pages and server helpers execute using installed Supabase2.111 with synthetic fetch; actual Desk/UsersDesk/CommandForm/Viz components render their returned props. The Shell and Next router/server-action wire are explicit local adapters. No provider writes or full Next framework/auth integration.',counts:{checks:checks.length,passed:checks.filter(x=>x.status==='passed').length,failed:checks.filter(x=>x.status==='failed').length,renderedRoutes:routeCoverage.length},checks,routeCoverage,actions,browserErrors:errors,limits:['Operation successful receipt is a controlled RPC reply; database mutation correctness remains a separate SQL/CI contract.','No authenticated hosted route was accepted by this fixture.','OperationsPanel/RecoveryForms/ReviewForm are explicitly uncovered component families where present.','No per-action denominator is inferred from a route render or a generic shared-component check.']};fs.writeFileSync(OUT+'/actual-pages-browser-audit.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt.counts));console.log(JSON.stringify(checks.filter(c=>c.status==='failed')));await context.close();await browser.close();await new Promise(r=>server.close(r));
 }
}
main().catch(e=>{console.error(e);process.exitCode=1});
