import React from 'react';
import {createRoot} from 'react-dom/client';
import {Desk,StatStrip} from '@/components/Desk';
import * as Viz from '@/components/Viz';
import CommandForm from '@/components/CommandForm';
import UsersDesk from '@/components/UsersDesk';
import ReportsDesk from '@/components/ReportsDesk';
import AdminIcon from '@/components/AdminIcon';
import Seal from '@/components/Seal';
import ContentReviewLink from '@/components/ContentReviewLink';
import RefreshDesk from '@/components/RefreshDesk';
import StaffRoleGuide from '@/components/StaffRoleGuide';
import PresentBuilder from '@/components/PresentBuilder';
import AuthPanel from '@/components/AuthPanel';
import Image from 'next/image';
import Link from './router-adapter';
import {invoke} from './action-bridge';
declare global {interface Window {__AUDIT_PAGE__: any;__AUDIT_ACTIONS__: any[]}}
window.__AUDIT_ACTIONS__=[];
function Shell(props:any){return <main data-pc-staff={'synthetic:'+props.admin.id+':'+props.admin.role} className="pc-workspace" style={{maxWidth:1600,margin:'auto',padding:24}}><p role="note">Actual server-page output · synthetic transport · no live mutations</p><h1>{props.title}</h1><p>{props.sub}</p>{props.pageActions}{props.children}</main>}
function Uncovered(props:any){return <section data-audit-uncovered={props.kind}>This control family requires its separate authentication/provider audit.</section>}
const components:any={Shell,Desk,StatStrip,...Viz,CommandForm,UsersDesk,ReportsDesk,AdminIcon,Seal,ContentReviewLink,RefreshDesk,StaffRoleGuide,PresentBuilder,AuthPanel,Image,Link,OperationsPanel:(p:any)=><Uncovered kind="OperationsPanel" {...p}/>,RecoveryForms:(p:any)=><Uncovered kind="RecoveryForms" {...p}/>,ReviewForm:(p:any)=><Uncovered kind="ReviewForm" {...p}/>};
function revive(value:any):any{
 if(value==null||typeof value!=='object')return value;
 if(value.__auditAction)return (data:FormData)=>invoke(value.__auditAction,data);
 if(Array.isArray(value))return value.map(revive);
 if(value.type&&value.props){const t=value.type==='fragment'||value.type==='unknown'?React.Fragment:value.type.startsWith('component:')?components[value.type.slice(10)]:value.type;if(!t)return <Uncovered kind={value.type}/>;return React.createElement(t,Object.fromEntries(Object.entries(value.props).map(([k,v])=>[k,revive(v)])));}
 return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,revive(v)]));
}
createRoot(document.getElementById('root')!).render(revive(window.__AUDIT_PAGE__.tree));
