export async function invoke(action:string,data:FormData){
 const fields=await Promise.all([...data.entries()].map(async([key,value])=>[key,typeof value==='string'?value:{name:value.name,type:value.type,text:await value.text()}]));
 const scenario=new URLSearchParams(window.location.search).get('auditAction')||'confirmed';
 const response=await fetch('/__audit_action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,fields,scenario,role:new URLSearchParams(window.location.search).get('auditRole')||'super_admin'})});
 const result=await response.json();(window as any).__AUDIT_ACTIONS__.push(result);
 if(result.error)throw new Error(result.error);
 if(result.redirect){window.location.assign(result.redirect);return;}
 return result.value;
}
